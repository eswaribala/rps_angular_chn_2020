import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {IPost} from '../ipost';
import {PhotoService} from '../../services/photo.service';
import {ActivatedRoute, Router} from '@angular/router';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class GalleryComponent implements OnInit {

  products: IPost[];


  constructor(private photoService: PhotoService, private router: Router, private route: ActivatedRoute) {

  }

  ngOnInit() {

    this.products = this.route.snapshot.data.products.slice(1, 50);
    console.log(this.products);
    /*this.photoService.getPhotos().subscribe(response => {
      // console.log(response);
      this.products = response.slice(1, 50);
      console.log(this.products);
    });*/
  }

  getProductDetails(product) {
    console.log(product);
    // routing parameter
    // this.router.navigate(['/About', product.id]);
    // routing with complex data
    this.router.navigate(['/About'], { queryParams: {data: JSON.stringify(this.products)},  skipLocationChange: true });
  }
}
