import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {PhotoService} from '../services/photo.service';
import {ActivatedRoute, NavigationExtras, Router} from '@angular/router';
import {IPost} from './ipost';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ProductComponent implements OnInit {
  products: IPost[];


  constructor(private photoService: PhotoService, private router: Router, private route: ActivatedRoute) {

  }

  ngOnInit() {

    this.products = this.route.snapshot.data.products.slice(1, 50);
    /*this.photoService.getPhotos().subscribe(response => {
      // console.log(response);
      this.products = response.slice(1, 50);
      console.log(this.products);
    });*/
  }

  getProductDetails(product) {
    console.log(product);
    // routing parameter
    // this.router.navigate(['/About', product.id]);
   // routing with complex data
    this.router.navigate(['/About'], { queryParams: {data: JSON.stringify(this.products)},  skipLocationChange: true });
  }
}
