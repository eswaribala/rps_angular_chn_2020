import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import {BreadcrumbModule} from 'primeng/breadcrumb';
import { HomeComponent } from './home/home.component';
import { ProductComponent } from './product/product.component';
import { AboutComponent } from './about/about.component';
import {HttpClientModule} from '@angular/common/http';
import {MatButtonModule, MatListModule} from '@angular/material';
import {MatIconModule} from '@angular/material';
import {MenubarModule} from 'primeng/menubar';
import {ProductPostsResolver} from './product/dataresolver';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    ProductComponent,
    AboutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BreadcrumbModule,
    MenubarModule,
    HttpClientModule,
    MatListModule,
    MatButtonModule,
    MatIconModule,

  ],
  providers: [ProductPostsResolver],
  bootstrap: [AppComponent]
})
export class AppModule { }
