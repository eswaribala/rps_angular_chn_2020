import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {HomeComponent} from './home/home.component';
import {ProductComponent} from './product/product.component';
import {AboutComponent} from './about/about.component';
import {ProductPostsResolver} from './product/dataresolver';


const routes: Routes = [{
  path: 'Home',
  component: HomeComponent,

  // outlet: 'home'
},
  {
    path: 'Product',
    component: ProductComponent,
    resolve: {
      products: ProductPostsResolver
    }

    // outlet: 'product'
  },

  // lazy loading
  {
    path: 'Order',
    loadChildren: () => import('./order/order.module').then(m => m.OrderModule)
  },
  /*{
    path: 'About/:id',
    component: AboutComponent,
    // outlet: 'about'
  },*/
  {
    path: 'About',
    component: AboutComponent,
    // outlet: 'about'
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
