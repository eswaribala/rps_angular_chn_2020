import {Menu} from './menu';

export let MenuData: Menu[] = [new Menu('Home'), new Menu('About'),
new Menu('Product')];
