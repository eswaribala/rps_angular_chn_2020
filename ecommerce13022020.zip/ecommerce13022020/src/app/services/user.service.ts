import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor( private http: HttpClient) {

  }

  public verifyUser(obj) {
    return this.http.get('https://daimalerblog2019-cf.cfapps.io/findboauserbyname/' + obj.userName);
  }
}
