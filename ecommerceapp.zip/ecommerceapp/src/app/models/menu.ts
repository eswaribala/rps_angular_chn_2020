export class Menu {
  // tslint:disable-next-line:variable-name
  private _label: string;

  constructor(label: string) {
    this._label = label;
  }


  get label(): string {
    return this._label;
  }

  set label(value: string) {
    this._label = value;
  }
}
